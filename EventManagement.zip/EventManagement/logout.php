<!DOCTYPE html>
<html>
<head>
	<title>Eva|Logout</title>
	<!--for-mobile-apps-->
		<meta name="viewport" content="width=device-width, initial-scale=1">
		<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
		<meta name="keywords" content="Mall Responsive Website Template, Web Templates, Flat Web Templates, Android Compatible web template, 
		Smartphone Compatible web template, free webdesigns for Nokia, Samsung, LG, Sony Ericsson, Motorola web design" />
		<script type="application/x-javascript"> addEventListener("load", function() { setTimeout(hideURLbar, 0); }, false); function hideURLbar(){ window.scrollTo(0,1); } </script>
	<!--//for-mobile-apps-->
	
	<!-- Custom-Theme-Files -->
    <!-- Bootstrap-CSS --> 			<link rel="stylesheet" href="css/bootstrap.min.css">
    <!-- JQuery --> 				<script src="js/jquery.min.js"></script>
    <!-- Bootstrap-Main --> 		<script src="js/bootstrap.min.js">		</script>
    <!-- Index-Page-Styling --> 	<link rel="stylesheet" href="css/style.css" type="text/css" media="all">
	<!-- Font-awesome-Styling --> 	<link rel="stylesheet" href="css/font-awesome.css" type="text/css" media="all">
	
</head>

<body>
<?php
session_start();
unset($_SESSION['userid']);
	unset($_SESSION['Eventid']);// will delete just the name data
session_destroy(); // will delete ALL data associated with that user.
?>
	
		
<div class="h-grid4"><!--h-grid4-->	
	<div class="container">
		<div class="h-grid4-padding-agileinfo">
			<h3>Thanks For Visiting..!</h3>
			<h4>You Have got Offer <span>20%</span> Discount</h4>
			<div class="timer_wrap">
				<div id="counter">
					<div class="under-text">
						 <a href="home.php">BOOK MORE</a>
					</div>					
				</div>		
			</div>
			
		</div> 
	</div>
</div><!--//h-grid4-->	
	
<div class="h-grid3"><!--h-grid3-->
	<div class="h-grid3-padding">
	  <h2>Also Explore Our Awesome Packages</h2>
			<div class="col-md-2 col-md-offset-1 h-grid3-all scroll wow zoomIn" data-wow-delay="1.5s">
				<i class="fa fa-paper-plane-o" aria-hidden="true"></i>
				<h4>MUSIC</h4>
				<p>Do visit to world class music concerts</p>
			</div>
			<div class="col-md-2 h-grid3-all scroll wow zoomIn" data-wow-delay="1s">
				<i class="fa fa-gift" aria-hidden="true"></i>
				<h4>GIFT VOCHER</h4>
				<p>Book tickets and get offer on next bookings..!!</p>
			</div>
			<div class="col-md-2 h-grid3-all scroll wow zoomIn" data-wow-delay="0.4s">
				<i class="fa fa-leaf" aria-hidden="true"></i>
				<h4>Feedback</h4>
				<p>Give feedback and get extra comfort</p>
			</div>
			<div class="col-md-2 h-grid3-all scroll wow zoomIn" data-wow-delay="1s">
				<i class="fa fa-shopping-bag" aria-hidden="true"></i>
				<h4>Travel</h4>
				<p>You Can Also Book Travel Tickets</p>
			</div>
			<div class="col-md-2 h-grid3-all scroll wow zoomIn" data-wow-delay="1.5s">
				<i class="fa fa-trello" aria-hidden="true"></i>
				<h4>Party Hard</h4>
				<p>Do book party tickets and enjoy</p>
			</div>
		  <div class="clearfix"> </div>
		</div>
</div>
	</body>
</html>