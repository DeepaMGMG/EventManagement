<!DOCTYPE html>
<html>
<head>
	<title>Eva|Welcome</title>
	<!--for-mobile-apps-->
		<meta name="viewport" content="width=device-width, initial-scale=1">
		<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
		<meta name="keywords" content="Mall Responsive Website Template, Web Templates, Flat Web Templates, Android Compatible web template, 
		Smartphone Compatible web template, free webdesigns for Nokia, Samsung, LG, Sony Ericsson, Motorola web design" />
		<script type="application/x-javascript"> addEventListener("load", function() { setTimeout(hideURLbar, 0); }, false); function hideURLbar(){ window.scrollTo(0,1); } </script>
	<!--//for-mobile-apps-->
	
	<!-- Custom-Theme-Files -->
    <!-- Bootstrap-CSS --> 			<link rel="stylesheet" href="css/bootstrap.min.css">
    <!-- JQuery --> 				<script src="js/jquery.min.js"></script>
    <!-- Bootstrap-Main --> 		<script src="js/bootstrap.min.js">		</script>
    <!-- Index-Page-Styling --> 	<link rel="stylesheet" href="css/style.css" type="text/css" media="all">
	<!-- Font-awesome-Styling --> 	<link rel="stylesheet" href="css/font-awesome.css" type="text/css" media="all">
	
</head>

<body>
	<?php
	require('config.php');//connect to config file
	$id=$_GET['id'];
	// Start the session
   session_start();
	// Set session variables
$_SESSION["eventid"] = $id;
	$sql1 = "SELECT * FROM event_details WHERE event_id = '$id' ";
      $result = $conn->query($sql1);
       while($array=mysqli_fetch_array($result))
         {
			$title=$array['event_title'];
				$organiser=$array['event_organizer'];
				$detail=$array['event_detailed'];
				$venue=$array['event_venue'];
				$startdate=$array['event_startdate'];
				$enddate=$array['event_enddate'];
				$websiteurl=$array['event_website_url'];
				$price=$array['event_ticket_price'];
				$mobile1=$array['contact_no1'];
				$mobile2=$array['contact_no2'];
				$seat=$array['Seats'];
				$url=$array['booking_url'];
				$terms=$array['terms_conditions'];
			 $banner=$array['event_banner'];

?>	
	
	<div class="h-about">
	<div class="h-about-padding-agile">
	  <h2>DETAILS ABOUT EVENT</h2>
		<div class="col-md-4 h-about-img">
			
			<img <?php echo "src=$banner"; ?> alt="image" class="img-responsive">
		</div>
		
		<div class="col-md-4 h-about-text">
			<h4><?php echo $title;?> </h4>
				<p>	<?php echo $detail;?>
				</p><br />
				<p> Price:<?php echo $price;?><br />
					Organiser:<?php echo $organiser;?><br />
					Venue:<?php echo $venue;?><br />
					Starts On:<?php echo $startdate;?><br />
					Ends On:<?php echo $enddate;?><br />
					
					Price:<?php echo $price;?><br />
					Organiser:<?php echo $organiser;?><br />
					Venue:<?php echo $venue;?><br />
					Url To Book:<?php echo $url;?><br />
					Terms And Conditions:<?php echo $terms;?><br />
				</p><br />
			<div class="col-md-4 h-about-text">
				<form method="post" action="">
            <input type="submit" name="submit" value="BOOK NOW" />
						</form>
			</div>
		</div>
	
		</div>
	</div>
	
	<?php 
		 if (isset($_POST['submit'])) {
				if( isset($_SESSION['userid']) && !empty($_SESSION['userid']))
				{
                      header('Location: booking.php');
				}
			 else
			 {
				 header('Location: logindesign.php');
			 }
			 
		 }
		 }
	
	?>
</body>
</html>
