<!DOCTYPE html>
<html lang="en">
<head>
  <meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1.0, user-scalable=no">
  <meta http-equiv="X-UA-Compatible" content="IE=edge">
  <title>Registration</title>
  <!-- CORE CSS-->
  
  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/materialize/0.97.1/css/materialize.min.css">

<style type="text/css">
.margin {
  margin: 5px !important;
}

table {
    border-collapse: collapse;
    width: 100%;
}

th, td {
    text-align: center;
    padding: 8px;
}

tr:nth-child(even){background-color: #f2f2f2}
</style>
</head>
<body class="blue">
	
<?php 
	// Start the session
 session_start();
require('config.php');//connect to config file

	$sql1 = "SELECT u.username as 'Customer Name',
ed.event_title as 'Event Name',
ed.event_organizer as 'Event Organizer',
ed.event_startdate as 'Event date', 
ev.no_tickets as 'No of Tickets', 
ev.total_price as 'Total Price'
FROM event_booking ev,
users u,
event_details ed 
where ev.user_id=u.id
AND ev.event_id=ed.event_id";
	
$result =mysqli_query($conn,$sql1);
echo '<table>
    <tr>
        <th>Customer Name</th>
        <th> Event Name</th>
		 <th>Event Organizer</th>
		  <th>Event date</th>
		   <th>No of Tickets</th>
		    <th>Total Price</th>
			
    </tr>';
  //loop the result set
  while ($row = mysqli_fetch_array($result))
          { 
	   echo '
        <tr>
            <td>'.$row['Customer Name'].'</td>
            <td>'.$row['Event Name'].'</td>
			<td>'.$row['Event Organizer'].'</td>
            <td>'.$row['Event date'].'</td>
			<td>'.$row['No of Tickets'].'</td>
            <td>'.$row['Total Price'].'</td>
        </tr>';
           }
	echo '
</table>';
$conn->close();
		
	
	?>
	
  <!-- jQuery Library -->
 <script type="text/javascript" src="//ajax.googleapis.com/ajax/libs/jquery/1.11.2/jquery.min.js"></script>
  <!--materialize js-->
  <script src="https://cdnjs.cloudflare.com/ajax/libs/materialize/0.97.1/js/materialize.min.js"></script>

</body>

</html>


