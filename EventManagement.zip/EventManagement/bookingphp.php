<?php 
// Start the session
   session_start();
	require('config.php');//connect to config file
	$userid= $_SESSION["userid"] ;
	echo $userid;
	$eventid=$_SESSION["eventid"];
	echo $eventid;
	$sql1 = "SELECT * FROM event_details WHERE event_id = '$eventid' ";
      $result = $conn->query($sql1);
       while($array=mysqli_fetch_array($result))
         {
			 echo "I am event";
			 $title=$array['event_title'];
				$organiser=$array['event_organizer'];
				$detail=$array['event_detailed'];
				$venue=$array['event_venue'];
				$startdate=$array['event_startdate'];
				$enddate=$array['event_enddate'];
				$websiteurl=$array['event_website_url'];
				$price=$array['event_ticket_price'];
				$mobile1=$array['contact_no1'];
				$mobile2=$array['contact_no2'];
				$seat=$array['Seats'];
				$url=$array['booking_url'];
				$terms=$array['terms_conditions'];
			 $banner=$array['event_banner'];
			
		 }
	
	$sql2 = "SELECT * FROM users WHERE id = '$userid' ";
      $result2 = $conn->query($sql2);
       while($array2=mysqli_fetch_array($result2))
         {
			 echo "I am user";
			 $uname=$array2['username'];
				$lname=$array2['lastname'];
				$email=$array2['email'];
				$num=$array2['mobile'];
				$address=$array2['Address'];
		 }
	
	echo "Summary:";
	echo "<br />";
	$tnum=$_POST['ticket'];
	$Total = $price * $tnum;
echo "totsl:";
	echo $Total;
	$sql = mysqli_query($conn,"INSERT INTO event_booking (event_id,user_id,no_tickets,total_price) VALUES ($eventid,$userid,$tnum,$Total)");
$sql = mysqli_query($conn,"UPDATE event_details SET Seats=Seats-$tnum where event_id=$eventid");
	
	echo "Yor tickets are reserved.Thank you for Booking!";

	echo "Total Price is";
	echo $Total;
		}
	else
		echo "not done";
	?>
