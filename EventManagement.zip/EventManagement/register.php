<html>
<head>
<title>My Profile</title>
</head>
<body>
<?php  
require('config.php');//connect to config file
$name=$_POST['name'];
$email=$_POST['email'];
$pass=$_POST['password'];
$mobile=$_POST['mobile'];
$adress=$_POST['adress'];
$lastname=$_POST['lastname'];
	
//Checking the values are existing in the database or not
$query = "SELECT * FROM `users` WHERE username='$name' and email='$email'";
 
$result = mysqli_query($conn, $query) or die(mysqli_error($conn));
$count = mysqli_num_rows($result);
//3.1.2 If the posted values are equal to the database values, then session will be created for the user.
if ($count == 1){
	echo "You Already Have Account.Please Login to Book Tickets";
}
else
{
			$sql = "INSERT INTO users (username, lastname, password, email, mobile, Address, Status,usertype) 
			VALUES ('$name','$lastname','$pass','$email','$mobile','$adress','1','2')";

			if ($conn->query($sql) === TRUE) {
				echo "Your Account Created Successfully";
			} else {
				echo "Error: " . $sql . "<br>" . $conn->error;
			}
}

$conn->close();
?> 
	
</body>

</html>
