<html>
<head>
	<title>TICKET</title>
	<meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1.0, user-scalable=no">
  <meta http-equiv="X-UA-Compatible" content="IE=edge">
  <title>Registration</title>
  <!-- CORE CSS-->
  
  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/materialize/0.97.1/css/materialize.min.css">
<script type="text/javascript">
     function printPage(){
            var tableData = '<table border="1">'+document.getElementsByTagName('table')[0].innerHTML+'</table>';
            var data = '<button onclick="window.print()">PRINT TICKET</button>'+tableData;       
            myWindow=window.open('','','width=800,height=600');
            myWindow.innerWidth = screen.width;
            myWindow.innerHeight = screen.height;
            myWindow.screenX = 0;
            myWindow.screenY = 0;
            myWindow.document.write(data);
            myWindow.focus();
        };
     </script>
<style type="text/css">
html,
body {
    height: 100%;
}
html {
    display: table;
    margin: auto;
}
body {
    display: table-cell;
    vertical-align: middle;
}
.margin {
  margin: 0px !important;
}

table {
    border-collapse: collapse;
    width: 100%;
}

th, td {
    text-align: center;
  
}

tr:nth-child(even){background-color: #f2f2f2}
}
</style>
</head>
<body>
	<h1>TICKET BOOKING</h1>	
	<?php 
	session_start();
	require('config.php');//connect to config file
	$userid= $_SESSION["userid"] ;
	$eventid=$_SESSION["eventid"];
	$tnum=$_SESSION["ticketss"];
	$sql1 = "SELECT * FROM event_details WHERE event_id = '$eventid' ";
      $result = $conn->query($sql1);
       while($array=mysqli_fetch_array($result))
         {
			$title=$array['event_title'];
				$organiser=$array['event_organizer'];
				$detail=$array['event_detailed'];
				$venue=$array['event_venue'];
				$startdate=$array['event_startdate'];
				$enddate=$array['event_enddate'];
				$websiteurl=$array['event_website_url'];
				$price=$array['event_ticket_price'];
			$_SESSION["price"]=$price;
				$mobile1=$array['contact_no1'];
				$mobile2=$array['contact_no2'];
				$seat=$array['Seats'];
				$url=$array['booking_url'];
				$terms=$array['terms_conditions'];
			$banner=$array['event_banner'];
		}
	$sql2 = "SELECT * FROM users WHERE id = '$userid' ";
      $result2 = $conn->query($sql2);
       while($array2=mysqli_fetch_array($result2))
         {
			$uname=$array2['username'];
				$lname=$array2['lastname'];
				$email=$array2['email'];
				$num=$array2['mobile'];
				$address=$array2['Address'];
		}
	echo "<br />";
	$Total = $price * $tnum;
	$sqlinsert = mysqli_query($conn,"INSERT INTO event_booking (event_id,user_id,no_tickets,total_price) VALUES ($eventid,$userid,$tnum,$Total)");
    $sqlupdate = mysqli_query($conn,"UPDATE event_details SET Seats=Seats-$tnum where event_id=$eventid");
	
	echo "Yor tickets are reserved.Thank you for Booking!<br /><br />";
	?>
<div id="div_print">
	<table id="your_content" >
	<tr>	
	       <td><img src="images/logo123.png" alt="LOGO"></td>
			<td><h4>TICKET FOR <?php echo $title ?></h4></td>
		  <td><img src="https://chart.googleapis.com/chart?chs=100x100&cht=qr&chl=<?php echo '$uname' ?>&choe=UTF-8" title="Link to Google.com" /></td></tr>
		</tr>
		<tr>	
			<td><h6>Name:</h6></td>
		   <td><?php echo $uname ?><td>
			
		</tr>
		
		<tr>
		<td><h6>Confirmation is Sent To:</h6></td>
		<td><?php echo $email ?><td>
		
		</tr>
		
		<tr>
		<td><h6>Message is Sent To:</h6></td>
		<td><?php echo $num ?><td>
				
		<tr>
		
			<td><h6>Total Price is</h6></td><td><?php echo $Total ?><td></tr>
		</table>
	
	</div>
	
<a href="javascript:void(0);" onclick="printPage();"><h4>Print</h4></a> 
	
	<!-- jQuery Library -->
 <script type="text/javascript" src="//ajax.googleapis.com/ajax/libs/jquery/1.11.2/jquery.min.js"></script>
  <!--materialize js-->
  <script src="https://cdnjs.cloudflare.com/ajax/libs/materialize/0.97.1/js/materialize.min.js"></script>

	</body>
</html>