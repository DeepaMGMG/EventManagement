<!DOCTYPE html>
<html>
<head>
	<title>Booking</title>
	<meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1.0, user-scalable=no">
  <meta http-equiv="X-UA-Compatible" content="IE=edge">
  <title>Registration</title>
  <!-- CORE CSS-->
  
  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/materialize/0.97.1/css/materialize.min.css">

<style type="text/css">
html,
body {
    height: 100%;
}
html {
    display: table;
    margin: auto;
}
body {
    display: table-cell;
    vertical-align: middle;
}
.margin {
  margin: 0 !important;
}
</style>
</head>
<body class="blue">
	<h1>TICKET BOOKING</h1>
	<?php 
	// Start the session
   session_start();
	require('config.php');//connect to config file
	$userid= $_SESSION["userid"] ;
	$eventid=$_SESSION["eventid"];
	$sql1 = "SELECT * FROM event_details WHERE event_id = '$eventid' ";
      $result = $conn->query($sql1);
       while($array=mysqli_fetch_array($result))
         {
			 $title=$array['event_title'];
				$organiser=$array['event_organizer'];
				$detail=$array['event_detailed'];
				$venue=$array['event_venue'];
				$startdate=$array['event_startdate'];
				$enddate=$array['event_enddate'];
				$websiteurl=$array['event_website_url'];
				$price=$array['event_ticket_price'];
			 $_SESSION["price"]=$price;
				$mobile1=$array['contact_no1'];
				$mobile2=$array['contact_no2'];
				$seat=$array['Seats'];
				$url=$array['booking_url'];
				$terms=$array['terms_conditions'];
			 $banner=$array['event_banner'];
		 }
	?>
	
  <div id="login-page" class="row">
    <div class="col s12 z-depth-6 card-panel">
		<form method="post" action="">
			<h6 style="color:green;"><b>Event Name:</b><?php echo $title; ?></h6><br />
			<h6 style="color:green;"><b>On:</b><?php echo $startdate; ?></h6><br />	
			<h6 style="color:green;"><b>Ticket Price:</b><?php echo $price; ?></h6><br />
			<h6 style="color:green;"><b>Seat Available:</b><?php echo $seat; ?></h6><br />
			
		<div class="row margin">
          <div class="input-field col s6">
            <input id="ticket" type="text" name="ticket">
			  <label for="ticket" class="center-align">Enter Number of Tickets</label>
          </div>
        </div>
		
        <br />
            <input type="submit" name="submit" value="BOOK NOW" />
		  </form>
	</div>
 </div>
	<?php 
	echo "Summary:";
	echo "<br />";
	if (isset($_POST['submit'])) {
	$tnum=$_POST['ticket'];
	$_SESSION["ticketss"]=$tnum;
		if( $tnum>5)
		{
			echo "Sorry !! your booking Not done<br />";
			echo "You can Book upto 5 Tickets only";
		}
		else
		{
			header('Location: confirm.php');	
		}
	}
		?>
	
	<!-- jQuery Library -->
 <script type="text/javascript" src="//ajax.googleapis.com/ajax/libs/jquery/1.11.2/jquery.min.js"></script>
  <!--materialize js-->
  <script src="https://cdnjs.cloudflare.com/ajax/libs/materialize/0.97.1/js/materialize.min.js"></script>

</body>
</html>
