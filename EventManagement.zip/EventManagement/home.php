<!--
Author: W3layouts
Author URL: http://w3layouts.com
License: Creative Commons Attribution 3.0 Unported
License URL: http://creativecommons.org/licenses/by/3.0/
-->
<!DOCTYPE html>
<html>
<head>
	<title>Eva|Welcome</title>
	<!--for-mobile-apps-->
		<meta name="viewport" content="width=device-width, initial-scale=1">
		<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
		<meta name="keywords" content="Mall Responsive Website Template, Web Templates, Flat Web Templates, Android Compatible web template, 
		Smartphone Compatible web template, free webdesigns for Nokia, Samsung, LG, Sony Ericsson, Motorola web design" />
		<script type="application/x-javascript"> addEventListener("load", function() { setTimeout(hideURLbar, 0); }, false); function hideURLbar(){ window.scrollTo(0,1); } </script>
	<!--//for-mobile-apps-->
	
	<!-- Custom-Theme-Files -->
    <!-- Bootstrap-CSS --> 			<link rel="stylesheet" href="css/bootstrap.min.css">
    <!-- JQuery --> 				<script src="js/jquery.min.js"></script>
    <!-- Bootstrap-Main --> 		<script src="js/bootstrap.min.js">		</script>
    <!-- Index-Page-Styling --> 	<link rel="stylesheet" href="css/style.css" type="text/css" media="all">
	<!-- Font-awesome-Styling --> 	<link rel="stylesheet" href="css/font-awesome.css" type="text/css" media="all">
	
</head>

<body>

<div class="header">
	<div class="nav">
		<nav class="navbar navbar-inverse navbar-fixed-top">
			<div class="container">
			  <!-- Brand and toggle get grouped for better mobile display -->
				<div class="navbar-header">
					<button type="button" class="navbar-toggle collapsed" data-toggle="collapse" data-target="#bs-example-navbar-collapse-1" aria-expanded="false">
						<span class="sr-only">Toggle navigation</span>
						<span class="icon-bar"></span>
						<span class="icon-bar"></span>
						<span class="icon-bar"></span>
					</button>
				   <a class="navbar-brand" href="index.html"><h1>Eva</h1></a>
				</div>
			  <!-- Collect the nav links, forms, and other content for toggling -->
				<div class="collapse navbar-collapse" id="bs-example-navbar-collapse-1">
					<ul class="nav navbar-nav navbar-right menu slide">
						<li><a href="index.html" class="orange">OUTDOOR</a></li>
						<li><a href="shopping.html" class="orange">MUSIC</a></li>
						<li><a href="dining.html" class="orange">DINING</a></li>
						<li><a href="entertainment.html" class="orange">PRODUCT LAUNCH</a></li>
						<li><a href="logindesign.php?Loginid=1" class="orange">LOGIN</a></li>
						<li><a href="register.html" class="orange">REGISTER</a></li>
						<li><a href="logindesign.php?Loginid=2" class="orange">ADMIN</a></li>
						<li><a href="logout.php" class="orange">LOGOUT</a></li>
					</ul>
				</div><!-- navbar-collapse -->
			</div><!-- container -->
		</nav>
		  <div class="clearfix"></div>
	</div> <!-- Nav Ends -->
		
  <div class="clearfix"> </div>
</div><!--//header-->
		
	<div class="s-banner"> <!--banner -->
		
	</div> <!--//banner -->

<?php 
	require('config.php');//connect to config file
	$sql1 = "SELECT * FROM event_details";
    $result =mysqli_query($conn,$sql1);
	$count = mysqli_num_rows($result);
	if($count > 0)
	{
		while ($row=mysqli_fetch_assoc($result))
			{ 
				$id=$row['event_id'];
				$title=$row['event_title'];
				$organiser=$row['event_organizer'];
				$detail=$row['event_detailed'];
				$venue=$row['event_venue'];
				$startdate=$row['event_startdate'];
				$enddate=$row['event_enddate'];
				$websiteurl=$row['event_website_url'];
				$price=$row['event_ticket_price'];
				$mobile1=$row['contact_no1'];
				$mobile2=$row['contact_no2'];
				$seat=$row['Seats'];
				$url=$row['booking_url'];
				$terms=$row['terms_conditions'];
			 $banner=$row['event_banner'];
				?>
	<div class="s-grid3">
	<div class="container">
		<div class="s-grid3-padding">
				<div class="col-md-6 col-sm-6 egrid">
				<div class="img">
					<img <?php echo "src=$banner"; ?> alt="">
				</div>
				<div class="textt">
					<h3><?php echo $title;?></h3>
					<label class="eline"></label>
					<p><?php echo $detail;?></p>
					 <a href="readmore.php?id=<?php echo $id;?>">READ MORE</a>
				</div>
			  <div class="clearfix"></div>
			</div>
		</div>
		</div>
	</div>
	<?php		}
	}
	else
	{
		 echo 'no data';
	}
	?>
	
	
	<div class="h-grid5-w3layouts"><!--h-grid5 gallery-->
	<div class="container">
		<div class="h-grid5-padding">
			<h3>Gallery</h3>
			
			<div class="h-grid5">
				<div class="col-md-3  h-grid5-all " >
					<a href="http://brightevents.com/img/slides/Sony-Cine-Europe-medium.jpg" class="swipebox hovereffect">  <img src="http://brightevents.com/img/slides/Sony-Cine-Europe-medium.jpg" alt="image" class="hex"> </a>
				</div>
				<div class="col-md-3 h-grid5-all "> 
					<a href="http://brightrentals.com/assets/upload/Homepage28.png" class="swipebox hovereffect">  <img src="http://brightrentals.com/assets/upload/Homepage28.png" alt="image" class="hex">  </a>
				</div>
				<div class="col-md-3 h-grid5-all">
					<a href="https://brightbrain.events/wp-content/uploads/2016/04/g_image_01.jpg" class="swipebox hovereffect">  <img src="https://brightbrain.events/wp-content/uploads/2016/04/g_image_01.jpg" alt="image" class="hex"> </a>
				</div>
				<div class="col-md-3 h-grid5-all">
					<a href="https://brightbrain.events/wp-content/uploads/2016/04/g_image_04.jpg" class="swipebox hovereffect">  <img src="https://brightbrain.events/wp-content/uploads/2016/04/g_image_04.jpg" alt="image" class="hex"> </a>
				</div>
			  <div class="clearfix"> </div>
			</div>
			
			<div class="h-grid5">
				<div class="col-md-3 col-md-offset-1 h-grid5-all h-grid5-m" >
					<a href="https://brightbrain.events/wp-content/uploads/2016/04/g_image_02.jpg" class="swipebox hovereffect">  <img src="https://brightbrain.events/wp-content/uploads/2016/04/g_image_02.jpg" alt="image" class="hex"> </a>
				</div>
				<div class="col-md-3 h-grid5-all h-grid5-m">
					<a href="https://brightbrain.events/wp-content/uploads/2016/04/g_image_10.jpg" class="swipebox hovereffect">  <img src="https://brightbrain.events/wp-content/uploads/2016/04/g_image_10.jpg" alt="image" class="hex"> </a>
				</div>
				<div class="col-md-3 h-grid5-all h-grid5-m">
					<a href="https://brightbrain.events/wp-content/uploads/2016/04/g_image_13.jpg" class="swipebox hovereffect">  <img src="https://brightbrain.events/wp-content/uploads/2016/04/g_image_13.jpg" alt="image" class="hex"> </a>
				</div>
			  <div class="clearfix"> </div>
			</div>
			
			<div class="h-grid5">
				<div class="col-md-3  h-grid5-all " >
					<a href="https://brightbrain.events/wp-content/uploads/2016/04/g_image_10.jpg" class="swipebox hovereffect">  <img src="https://brightbrain.events/wp-content/uploads/2016/04/g_image_10.jpg" alt="image" class="hex"> </a>
				</div>
				<div class="col-md-3 h-grid5-all ">
					<a href="https://brightbrain.events/wp-content/uploads/2016/04/g_image_13.jpg" class="swipebox hovereffect">  <img src="images/49.jpg" alt="image" class="hex"> </a>
				</div>
				<div class="col-md-3 h-grid5-all ">
					<a href="https://brightbrain.events/wp-content/uploads/2016/04/g_image_14.jpg" class="swipebox hovereffect">  <img src="https://brightbrain.events/wp-content/uploads/2016/04/g_image_14.jpg" alt="image" class="hex"> </a>
				</div>
				<div class="col-md-3 h-grid5-all ">
					<a href="https://brightbrain.events/wp-content/uploads/2016/04/g_image_14.jpg" class="swipebox hovereffect">  <img src="https://brightbrain.events/wp-content/uploads/2016/04/g_image_14.jpg" alt="image" class="hex"> </a>
				</div>
			  <div class="clearfix"> </div>
			</div>
			
		  <div class="clearfix"> </div>
		</div>
		<!-- swipe box js -->
		<script src="js/jquery.swipebox.js"></script>
				<script type="text/javascript">
					;( function( $ ) {

						$( '.swipebox' ).swipebox();

					} )( jQuery );
				</script>
		<!-- //swipe box js -->
	</div>
</div><!--//h-grid5-->	
	
</body>
</html>
