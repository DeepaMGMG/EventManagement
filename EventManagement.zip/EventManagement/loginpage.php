<!DOCTYPE html>
<html lang="en">
<head>
  <meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1.0, user-scalable=no">
  <meta http-equiv="X-UA-Compatible" content="IE=edge">
  <title>Registration</title>
  <!-- CORE CSS-->
  
  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/materialize/0.97.1/css/materialize.min.css">

<style type="text/css">
html,
body {
    height: 100%;
}
html {
    display: table;
    margin: auto;
}
body {
    display: table-cell;
    vertical-align: middle;
}
.margin {
  margin: 0 !important;
}
</style>
  
</head>

<body class="blue">
<?php 
	// Start the session
 session_start();
require('config.php');//connect to config file
			
	?>

  <div id="login-page" class="row">
    <div class="col s12 z-depth-6 card-panel">
      <form method="post" action="">
        
        <div class="row margin">
          <div class="input-field col s12">
            <i class="mdi-communication-email prefix"></i>
            <input id="email" type="email" name="email">
            <label for="email" class="center-align">Email</label>
          </div>
        </div>
      
        <div class="row margin">
          <div class="input-field col s12">
            <i class="mdi-action-lock-outline prefix"></i>
            <input id="password" type="password" name="pass" >
            <label for="password">Password</label>
          </div>
        </div>
       
        <br />
            <input type="submit" name="submit" value="Submit" />
		  
          <div class="input-field col s12">
            <p class="margin center medium-small sign-up">Please Register <a href="register.html">Signup</a></p>
        </div>
      </form>
    </div>
  </div>
<?php
	if (isset($_POST['submit'])) {
			$email = $_POST['email'];
			$pass = $_POST['pass'];

			if ($conn->connect_error) {
				die("Connection failed: " . $conn->connect_error);
			}
			$sql1 = "SELECT * FROM users WHERE `email` = '$email' and password = '$pass'";
				$result =mysqli_query($conn,$sql1);
				if ($row = mysqli_fetch_assoc($result))
				{
				    $userid=$row['id'];
					 $usertype=$row['usertype'];
					echo "Login Successfully";
				}
			else 
			{
					echo "Incorrect Email or Password!!!";
				header('Location: logindesign.php');
				}
			$conn->close();
	
			 }
	?>

  <!-- jQuery Library -->
 <script type="text/javascript" src="//ajax.googleapis.com/ajax/libs/jquery/1.11.2/jquery.min.js"></script>
  <!--materialize js-->
  <script src="https://cdnjs.cloudflare.com/ajax/libs/materialize/0.97.1/js/materialize.min.js"></script>

</body>

</html>

