<html>
<head>
<title>Admin</title>
</head>
<body>
<?php  
require('config.php');//connect to config file
$eventname=$_POST['eventname'];
$organiser=$_POST['organiser'];
$eventdetail=$_POST['eventdetail'];
$venue=$_POST['venue'];
$startdate=$_POST['startdate'];
$enddate=$_POST['enddate'];
$websiteurl=$_POST['websiteurl'];
$ticketprice=$_POST['ticketprice'];
$mobile1=$_POST['mobile1'];
$mobile2=$_POST['mobile2'];
$seats=$_POST['seats'];
$bookingurl=$_POST['bookingurl'];
$terms=$_POST['terms'];
$banner=$_POST['banner'];
	
	$sql = "INSERT INTO event_details (event_title, event_organizer, event_detailed, event_venue, event_startdate, event_enddate, event_website_url, event_ticket_price, contact_no1, contact_no2, Seats, booking_url, terms_conditions, event_banner) 
			VALUES ('$eventname','$organiser','$eventdetail','$venue','$startdate','$enddate','$websiteurl','$ticketprice','$mobile1','$mobile2','$seats','$bookingurl','$terms','$banner')";

			if ($conn->query($sql) === TRUE)
			{
				echo "Event Uploaded Successfully";
			} 
		else
	 		{
				echo "Error: " . $sql . "<br>" . $conn->error;
			}

$conn->close();
?> 
	
</body>

</html>

